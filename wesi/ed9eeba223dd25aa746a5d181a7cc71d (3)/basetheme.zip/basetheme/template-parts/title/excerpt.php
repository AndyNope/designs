<?php
/**
 * Template part for displaying a post's excerpt.
 *
 * @package thebase
 */

namespace TheBase;

?>
<div class="title-entry-excerpt">
	<?php the_excerpt(); ?>
</div><!-- .title-entry-excerpt -->
