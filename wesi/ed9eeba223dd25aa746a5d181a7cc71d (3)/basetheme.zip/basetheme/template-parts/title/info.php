<?php
/**
 * Template part for displaying a post's metadata
 *
 * @package thebase
 */

namespace TheBase;

do_action( 'thebase_single_title_info_area' );
