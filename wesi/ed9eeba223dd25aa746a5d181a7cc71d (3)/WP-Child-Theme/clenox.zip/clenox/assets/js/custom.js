// Custom JS
var n = jQuery.noConflict();
function isotopAutoSet() { 
    "use strict";
    // Testimonials
    jQuery(".testimonial-carousel").each(function() {
        "use strict";
            n(".testimonial-carousel .elementor-widget-wrap").addClass("owl-carousel");
            n(".testimonial-carousel .elementor-widget-wrap").owlCarousel({
                navigation: false,
                pagination: true,
                autoplay:3000,
                items: 2,
                itemsLarge: [1400, 2],
                itemsDesktop: [1200, 2],
                itemsDesktopSmall: [979, 1],
                itemsTablet: [600, 1],
                itemsMobile: [479, 1]
            })
    });	
    // Blog      
    jQuery(".blog-carousel").each(function() {
        "use strict";
        if (n(this).attr("id")) {
            var e = n(this).attr("id").replace("_blog_carousel", "");
            n(".blog-carousel").addClass("owl-carousel");
            n(".blog-carousel").owlCarousel({
                navigation: true,
                pagination: false,
                items: e,
                itemsLarge: [1400, e],
                itemsDesktop: [1200, e],
                itemsDesktopSmall: [979, 2],
                itemsTablet: [600, 2],
                itemsMobile: [479, 1]
            })
        }
    });
}
jQuery(window).on('load',function() {  "use strict";  isotopAutoSet()});
jQuery(window).resize(function() { "use strict"; isotopAutoSet()});


// JS toggle for sidebar and footer
function SidebarFooterToggle() {
    "use strict";
    jQuery('footer .widget h3,footer .widget .widget-title').parent().addClass('toggled-off');
    jQuery('footer .widget h3,footer .widget .widget-title').on("click", function() {
        if (jQuery(this).parent().hasClass('toggled-on')) {
            jQuery(this).parent().removeClass('toggled-on');
            jQuery(this).parent().addClass('toggled-off');
        } else {
            jQuery(this).parent().addClass('toggled-on');
            jQuery(this).parent().removeClass('toggled-off');
        }
        return (false);
    });
}
jQuery(document).ready(function() {
    "use strict";
    SidebarFooterToggle()
});
jQuery(window).on('load', function() {
    "use strict";
    var $height = 0 ;
    jQuery(".product-action-wrap").each(function(){
   if((jQuery(this).height())>$height){
    $height = jQuery(this).height();
    }
    });
    jQuery("ul.products.woo-archive-action-on-hover .woo-archive-outer").each(function(){
    jQuery(this).css("margin-bottom",-$height - 6);
    jQuery(this).css("padding-bottom",$height + 6);
	jQuery("ul.align-buttons-bottom .product-action-wrap").css("bottom", -$height - 6);
    });

    jQuery('.thebase-show-sidebar-btn').on("click",function() { 
        jQuery(".primary-sidebar").toggleClass("active");
        jQuery(this).toggleClass("active");
    });
    jQuery('.thebase-hide-sidebar-btn .thebase-svg-iconset').on("click",function() { 
        jQuery(".primary-sidebar").removeClass("active");
        jQuery('.thebase-show-sidebar-btn').removeClass("active");
    });
    

});
jQuery('.widget_block').on("click",function() {
    jQuery('.product-categories').slideToggle("slow");
});