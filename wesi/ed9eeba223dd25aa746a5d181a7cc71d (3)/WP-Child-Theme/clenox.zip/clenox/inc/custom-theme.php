<?php
/**
 * Class for the Custom Theme
 *
 * @package thebase
 */

namespace TheBase\Custom_Theme;

use TheBase_Blocks_Frontend;
use TheBase\Component_Interface;
use TheBase\Templating_Component_Interface;
use TheBase\TheBase_CSS;
use LearnDash_Settings_Section;
use function TheBase\thebase;
use function TheBase\get_webfont_url;
use function TheBase\print_webfont_preload;
use function add_action;
use function add_filter;
use function wp_enqueue_style;
use function wp_register_style;
use function wp_style_add_data;
use function get_theme_file_uri;
use function get_theme_file_path;
use function wp_styles;
use function esc_attr;
use function esc_url;
use function wp_style_is;
use function _doing_it_wrong;
use function wp_print_styles;
use function post_password_required;
use function is_singular;
use function comments_open;
use function get_comments_number;
use function apply_filters;
use function add_query_arg;
use function wp_add_inline_style;

/**
 * Main plugin class
 */
class Custom_Theme {
	/**
	 * Instance Control
	 *
	 * @var null
	 */
	private static $instance = null;

	/**
	 * Holds theme array sections.
	 *
	 * @var the theme settings sections.
	 */
	private $update_options = array();

	/**
	 * Instance Control.
	 */
	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Throw error on object clone.
	 *
	 * The whole idea of the singleton design pattern is that there is a single
	 * object therefore, we don't want the object to be cloned.
	 *
	 * @return void
	 */
	public function __clone() {
		// Cloning instances of the class is forbidden.
		_doing_it_wrong( __FUNCTION__, esc_html__( 'Cloning instances of the class is Forbidden', 'basetheme' ), '1.0' );
	}

	/**
	 * Disable un-serializing of the class.
	 *
	 * @return void
	 */
	public function __wakeup() {
		// Unserializing instances of the class is forbidden.
		_doing_it_wrong( __FUNCTION__, esc_html__( 'Unserializing instances of the class is forbidden', 'basetheme' ), '1.0' );
	}

	/**
	 * Constructor function.
	 */
	public function __construct() {
		
		add_filter( 'thebase_theme_options_defaults', array( $this, 'add_option_defaults' ), 10 );
		add_filter( 'thebase_addons_theme_options_defaults', array( $this, 'add_addons_option_defaults' ), 10 );
		add_action( 'thebase_hero_header', array( $this, 'shop_filter' ), 5 );
		add_action( 'thebase_before_sidebar', array( $this, 'close_shop_filter' ), 5 );
		add_filter( 'thebase_global_palette_defaults', array( $this, 'add_color_option_defaults' ), 50 );
		add_filter( 'thebase_dynamic_css', array( $this, 'child_dynamic_css' ), 30 );
	}

	public function child_dynamic_css( $css ) {
		$generated_css = $this->generate_child_css();
		if ( ! empty( $generated_css ) ) {
		$css .= "\n/* Base Pro Header CSS */\n" . $generated_css;
		}
		return $css;
	}
	public function generate_child_css() {
		$css = new TheBase_CSS();		
		$css->set_selector( '.primary-sidebar.widget-area .widget-title, .widget_block h2,.widget_block .widgettitle,.widget_block .widgettitle' );
		$css->render_font( thebase()->option( 'sidebar_widget_title' ), $css );
	return $css->css_output();
	}

	/**
	 * set child theme Default color.
	 */
	public function add_color_option_defaults( $defaults ) {
		if ( is_null( $default_palette ) ) {
		$default_palette = '{"palette":[{"color":"#141414","slug":"palette1","name":"Palette Color 1"},
		{"color":"#00aff4","slug":"palette2","name":"Palette Color 2"},{"color":"#141414","slug":"palette3","name":"Palette Color 3"},
		{"color":"#646464","slug":"palette4","name":"Palette Color 4"},{"color":"#f3e921","slug":"palette5","name":"Palette Color 5"},
		{"color":"#14287b","slug":"palette6","name":"Palette Color 6"},{"color":"#f9f9fb","slug":"palette7","name":"Palette Color 7"},
		{"color":"#ffffff","slug":"palette8","name":"Palette Color 8"},{"color":"#ffffff","slug":"palette9","name":"Palette Color 9"}],"second-palette":[{"color":"#2B6CB0","slug":"palette1","name":"Palette Color 1"},{"color":"#215387","slug":"palette2","name":"Palette Color 2"},{"color":"#1A202C","slug":"palette3","name":"Palette Color 3"},{"color":"#2D3748","slug":"palette4","name":"Palette Color 4"},{"color":"#4A5568","slug":"palette5","name":"Palette Color 5"},{"color":"#718096","slug":"palette6","name":"Palette Color 6"},{"color":"#EDF2F7","slug":"palette7","name":"Palette Color 7"},{"color":"#FFFFFF","slug":"palette8","name":"Palette Color 8"},{"color":"#ffffff","slug":"palette9","name":"Palette Color 9"}],"third-palette":[{"color":"#2B6CB0","slug":"palette1","name":"Palette Color 1"},{"color":"#215387","slug":"palette2","name":"Palette Color 2"},{"color":"#1A202C","slug":"palette3","name":"Palette Color 3"},{"color":"#2D3748","slug":"palette4","name":"Palette Color 4"},{"color":"#4A5568","slug":"palette5","name":"Palette Color 5"},{"color":"#718096","slug":"palette6","name":"Palette Color 6"},{"color":"#EDF2F7","slug":"palette7","name":"Palette Color 7"},{"color":"#F7FAFC","slug":"palette8","name":"Palette Color 8"},{"color":"#ffffff","slug":"palette9","name":"Palette Color 9"}],"active":"palette"}';
	}
		return $default_palette;
		}

	/**
	 * Add Defaults
	 *
	 * @access public
	 * @param array $defaults registered option defaults with basetheme theme.
	 * @return array
	 */
	 /**
	 * Shop Filter
	 */
	public function shop_filter() {
		if (  thebase()->has_sidebar() ) {				
		echo '<div class="thebase-show-sidebar-btn thebase-action-btn thebase-style-text">';
		echo '<span class="drawer-overlay" data-drawer-target-string="#mobile-drawer"></span>';
		echo '<span class="menu-toggle-icon">'.thebase()->print_icon( 'menu', '', false ).'</span>';
		echo '</div>';
		}
	}
	/**
	 * Shop Filter Close
	 */
	public function close_shop_filter($sale) {
		if (  thebase()->has_sidebar() ) {	
		echo '<div class="thebase-hide-sidebar-btn">';
		echo '<span class="menu-toggle-icon">'.thebase()->print_icon( 'close', '', false ).'</span>';
		echo '</div>';
		}
	}	
	public function add_option_defaults( $defaults ) {

		$update_options = array(
			'content_width'   => array(
				'size' => 1248,
				'unit' => 'px',
			),
			'boxed_grid_spacing'   => array(
				'size' => array(
					'mobile'  => '',
					'tablet'  => '',
					'desktop' => 0,
				),
				'unit' => array(
					'mobile'  => 'rem',
					'tablet'  => 'rem',
					'desktop' => 'rem',
				),
			),
			'boxed_spacing'   => array(
				'size' => array(
					'mobile'  => 1.5,
					'tablet'  => 2.5,
					'desktop' => 4,
				),
				'unit' => array(
					'mobile'  => 'rem',
					'tablet'  => 'rem',
					'desktop' => 'rem',
				),
			),
			'boxed_grid_shadow' => array(
				'color'   => 'rgba(0,0,0,0)',
				'hOffset' => 0,
				'vOffset' => 0,
				'blur'    => 0,
				'spread'  => 0,
				'inset'   => false,
			),
			'boxed_shadow' => array(
				'color'   => 'rgba(0,0,0,0)',
				'hOffset' => 0,
				'vOffset' => 0,
				'blur'    => 0,
				'spread'  => 0,
				'inset'   => false,
			),
			'boxed_border_radius' => array(
						'size'   => array( '0', '0', '0', '0' ),
						'unit'   => 'px',
						'locked' => true,
					),
			// Typography.
			'base_font' => array(
				'size' => array(
					'desktop' => 16,
				),
				'lineHeight' => array(
					'desktop' => 1.6,
				),
				'letterSpacing' => array(
					'desktop' => '0.3',
				),
				'spacingType'=> 'px',
				'transform' => '',
				'family'  => 'Nunito',
				'google'  => true,
				'transform' => '',
				'weight'  => '400',
				'variant' => '400',
				'color'   => 'palette4',
			),
			'heading_font' => array(
				'family' => 'Rajdhani',
			),
			'h1_font' => array(
				'size' => array(
					'mobile' => 38,
					'tablet' => 46,
					'desktop' => 60,
				),
				'lineHeight' => array(
					'mobile' => '1',
					'tablet' =>'' ,
					'desktop' => 1.3 ,
				),
				'lineType' =>  '',
				'letterSpacing' => array(
					'mobile' => '0.3',
					'tablet' => '0.3',
					'desktop' => '0.3',
				),
				'spacingType'=> 'px',
				'transform' => 'capitalize',
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '700',
				'variant' => '700',
				'color'   => 'palette3',
			),	
			'h2_font' => array(
				'size' => array(
					'mobile' => 32,
					'tablet' => 40,
					'desktop' => 50,
				),
				'lineHeight' => array(
					'mobile' => '0.8',
					'tablet' => '',
					'desktop' => '1.2',
				),
				'lineType' =>  '',
				'letterSpacing' => array(
					'mobile' => '0.3',
					'tablet' => '0.3',
					'desktop' => '0.3',
				),
				'spacingType'=> 'px',
				'transform' => 'capitalize',
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '700',
				'variant' => '700',
				'color'   => 'palette3',
			),
			'h3_font' => array(
				'size' => array(
					'mobile' => 26,
					'tablet' => 30,
					'desktop' => 23,
				),
				'lineHeight' => array(
					'mobile' => '0.8',
					'tablet' => '',
					'desktop' => '1.2',
				),
				'lineType' =>  '',
				'letterSpacing' => array(
					'mobile' => '0.3',
					'tablet' => '0.3',
					'desktop' => '0.3',
				),
				'spacingType'=> 'px',
				'transform' => 'capitalize',
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '700',
				'variant' => '700',
				'color'   => 'palette3'
			),
			'h4_font' => array(
				'size' => array(
					'mobile' => 18,
					'tablet' => 20,
					'desktop' => 20,
				),
				'lineHeight' => array(
					'mobile' => '0.6',
					'tablet' => '',
					'desktop' => '1.1',
				),
				'lineType' =>  '',
				'letterSpacing' => array(
					'mobile' => '0.3',
					'tablet' => '0.3',
					'desktop' => '0.3',
				),
				'spacingType'=> 'px',
				'transform' => 'capitalize',
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '700',
				'variant' => '700',
				'color'   => 'palette3',
			),	
			'h5_font' => array(
				'size' => array(
					'mobile' => 16,
					'tablet' => 18,
					'desktop' => 18,
				),
				'lineHeight' => array(
					'mobile' => '0.6',
					'tablet' => '',
					'desktop' => '1',
				),
				'lineType' =>  '',
				'letterSpacing' => array(
					'mobile' => '0.3',
					'tablet' => '0.3',
					'desktop' => '0.3',
				),
				'spacingType'=> 'px',
				'transform' => 'capitalize',
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '700',
				'variant' => '700',
				'color'   => 'palette3'
			),
			'h6_font' => array(
				'size' => array(
					'mobile' => 14,
					'tablet' => 16,
					'desktop' => 16,
				),
				'lineHeight' => array(
					'mobile' => '0.6',
					'tablet' => '',
					'desktop' => '1',
				),
				'lineType' =>  '',
				'letterSpacing' => array(
					'mobile' => '0.3',
					'tablet' => '0.3',
					'desktop' => '0.3',
				),
				'spacingType'=> 'px',
				'transform' => 'capitalize',
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '700',
				'variant' => '700',
				'color'   => 'palette3',
			),	
			//Button
			'buttons_color'  => array(
				'color'  => 'palette1',
				'hover'  => 'palette9',
			),
			'buttons_background' => array(
				'color'  => 'palette5',
				'hover'  => 'palette2',
			),
			'buttons_typography'    => array(
				'size' => array(
					'desktop' => '16',
				),
				'lineHeight' => array(
					'desktop' => '24',
				),
				'lineType' =>  'px',
				'letterSpacing' => array(
					'desktop' => '0.3',
				),
				'spacingType'=> 'px',
				'transform' => 'capitalize',
				'family'  => 'Nunito',
				'google'  => false,
				'weight'  => '600',
				'variant' => '600',
			),
			'buttons_padding'        => array(
				'size'   => array(
					'mobile' => array( '10', '10', '10', '10' ),
					'tablet' => array( '15', '36', '15', '36' ),
					'desktop' => array( '15', '36', '15', '36' ),
				),
				'unit'   => array(
					'desktop' => 'px',
				),
				'locked' => array(
					'desktop' => false,
				),
			),
			'buttons_shadow' => array(
				'color'   => 'rgba(0,0,0,0)',
				'hOffset' => 0,
				'vOffset' => 0,
				'blur'    => 0,
				'spread'  => 0,
				'inset'   => false,
			),
			'buttons_shadow_hover' => array(
				'color'   => 'rgba(0,0,0,0)',
				'hOffset' => 0,
				'vOffset' => 0,
				'blur'    => 0,
				'spread'  => 0,
				'inset'   => false,
			),		
			'buttons_border_radius' => array(
				'size' => array(
					'mobile'  => '',
					'tablet'  => '',
					'desktop' => '0',
				),
				'unit' => array(
					'mobile'  => 'px',
					'tablet'  => 'px',
					'desktop' => 'px',
				),
			),	
			
			// Header.
			'header_desktop_items'       => array(
				'top' => array(
					'top_left'         => array('contact'),
					'top_left_center'  => array(),
					'top_center'       => array(),
					'top_right_center' => array(),
					'top_right'        => array('html','divider','account'),
				),
				'main' => array(
					'main_left'         => array( 'logo'),
					'main_left_center'  => array(),
					'main_center'       => array('navigation'),
					'main_right_center' => array(),
					'main_right'        => array( 'search','button' ),
				),
				'bottom' => array(
					'bottom_left'         => array(),
					'bottom_left_center'  => array(),
					'bottom_center'       => array(),
					'bottom_right_center' => array(),
					'bottom_right'        => array(),
				),				
			),		
			'header_main_background' => array(
				'desktop' => array(
					'color' => 'palette9',
				),
			),			
			'transparent_header_enable' => false,
			'transparent_header_archive'    => true,
			'transparent_header_page'       => false,
			'transparent_header_post'       => true,
			'transparent_header_product'    => true,
			// Header Top.
			'header_top_background'    => array(
				'desktop' => array(
					'color' => 'palette6',
				),
			),
			'header_top_height'       => array(
				'size' => array(
					'mobile'  => '',
					'tablet'  => '',
					'desktop' => 45,
				),
				'unit' => array(
					'mobile'  => 'px',
					'tablet'  => 'px',
					'desktop' => 'px',
				),
			),
			'header_top_layout'        => array(
				'mobile'  => '',
				'tablet'  => '',
				'desktop' => 'standard',
			),
			// Header Main.
			'header_main_height' => array(
				'size' => array(
					'mobile'  => 100,
					'tablet'  => 100,
					'desktop' => 100,
				),
				'unit' => array(
					'mobile'  => 'px',
					'tablet'  => 'px',
					'desktop' => 'px',
				),
			),
			'header_main_trans_background'    => array(
				'desktop' => array(
					'color' => 'palette9',
				),
			),
			'header_main_layout'         => array(
				'mobile'  => '',
				'tablet'  => '',
				'desktop' => 'contained',
			),				
			// Mobile Trigger.
			'mobile_trigger_color'   => array(
				'color' => 'palette1',
				'hover' => 'palette2',
			),
			// Mobile Navigation.
			'mobile_navigation_color'              => array(
				'color'  => 'palette8',
				'hover'  => 'palette5',
				'active' => 'palette5',
			),
			'mobile_navigation_typography'            => array(
				'size' => array(
					'desktop' => 16,
				),
				'lineHeight' => array(
					'desktop' => '',
				),
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '600',
				'variant' => '600',
			),
			// Mobile Header.
			'header_mobile_items' => array(
				'popup' => array(
					'popup_content' => array( 'mobile-navigation' ),
				),
				'top' => array(
					'top_left'   => array(),
					'top_center' => array('mobile-contact'),
					'top_right'  => array(),
				),
				'main' => array(
					'main_left'   => array( 'mobile-logo' ),
					'main_center' => array(),
					'main_right'  => array( 'popup-toggle','search' ),
				),
				'bottom' => array(
					'bottom_left'   => array(),
					'bottom_center' => array(),
					'bottom_right'  => array(),
				),
			),
			// Logo.
			'logo_width' => array(
				'size' => array(
					'mobile'  => '',
					'tablet'  => '',
					'desktop' => 177,
				),
				'unit' => array(
					'mobile'  => 'px',
					'tablet'  => 'px',
					'desktop' => 'px',
				),
			),
			'logo_layout'     => array(
				'include' => array(
					'mobile'  => 'logo_only',
					'tablet'  => 'logo_only',
					'desktop' => 'logo_only',
				),
			),
			'header_logo_padding' => array(
				'size'   => array( 
					'desktop' => array( '0', '3', '0', '0' ),
				),
				'unit'   => array(
					'desktop' => 'em',
				),
				'locked' => array(
					'desktop' => false,
				),
			),
			// Navigation.
			'primary_navigation_vertical_spacing'   => array(
				'size' => 2.3,
				'unit' => 'em',
			),
			'primary_navigation_typography' => array(
				'size' => array(
					'desktop' => '16',
				),
				'lineHeight' => array(
					'desktop' => '',
				),
				'weight'  => '600',				
			),
			'primary_navigation_spacing' => array(
				'size' => 1.8,
				'unit' => 'em',
			),
			'primary_navigation_color'   => array(
				'color'  => 'palette1',
				'hover'  => 'palette2',
				'active' => 'palette2',
			),
			// Dropdown.
			'dropdown_navigation_reveal' => 'fade-down',
			'dropdown_navigation_width'  => array(
				'size' => 250,
				'unit' => 'px',
			),
			'dropdown_navigation_vertical_spacing'   => array(
				'size' => 0.8,
				'unit' => 'em',
			),
			'dropdown_navigation_color'              => array(
				'color'  => 'palette1',
				'hover'  => 'palette1',
				'active' => 'palette1',
			),
			'dropdown_navigation_background'              => array(
				'color'  => 'palette9',
				'hover'  => 'palette5',
				'active' => 'palette5',
			),
			'dropdown_navigation_divider'              => array(
				'width' => 1,
				'unit'  => 'px',
				'style' => 'solid',
				'color' => 'rgba(0,0,0,0.1)',
			),
			'dropdown_navigation_typography'            => array(
				'size' => array(
					'desktop' => '16',
				),
				'lineHeight' => array(
					'desktop' => '',
				),
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '400',
				'variant' => '400',
			),
			// Header Button.
			'header_button_typography' => array(
				'size' => array(
					'desktop' => '16',
				),
				'lineHeight' => array(
					'desktop' => '',
				),
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '600',
				'variant' => '600',
			),
			'header_button_color' => array(
				'color' => 'palette1',
				'hover' => 'palette9',
			),
			'header_button_background'  => array(
				'color' => 'palette5',
				'hover' => 'palette2',
			),
			'header_button_label'      => __( 'Get A Quote', 'basetheme' ),
			'header_button_link' => '#',
			// Header Search.
			'header_search_icon'   => 'search2',
			'header_search_icon_size' => array(
				'size' => array(
					'mobile'  => '',
					'tablet'  => '1.3',
					'desktop' => '1.3',
				),
				'unit' => array(
					'mobile'  => 'em',
					'tablet'  => 'em',
					'desktop' => 'em',
				),
			),
			'header_search_margin' => array(
				'size'   => array( '0', '5', '0', '0' ),
				'unit'   => 'px',
				'locked' => false,
			),
			'header_search_color' => array(
				'color' => 'palette1',
				'hover' => 'palette2',
			),
			'header_search_modal_color' => array(
				'color' => 'palette9',
				'hover' => 'palette9',
			),
			// Page Layout.
			'page_title_background'  => array(
				'desktop' => array(
				'type' => 'image',
				'image' => array(
				'url' => get_stylesheet_directory_uri() .'/assets/images/breadcrumb.jpg',
				'repeat' => 'no-repeat',
				'size' => 'cover',
				'attachment' => 'scroll',
				),
				),
			),
			'page_content_style'      => 'unboxed',
			'page_title_height'       => array(
				'size' => array(
					'mobile'  => '120',
					'tablet'  => '150',
					'desktop' => '200',
				),
				'unit' => array(
					'mobile'  => 'px',
					'tablet'  => 'px',
					'desktop' => 'px',
				),
			),
			'page_title_font'   => array(
				'size' => array(
					'desktop' => '',
				),
				'lineHeight' => array(
					'desktop' => '',
				),
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '',
				'variant' => '',
				'color'   => 'palette9',
			),
			'page_title_breadcrumb_color' => array(
				'color' => 'palette9',
				'hover' => 'palette9',
			),
			'page_title_breadcrumb_font'   => array(
				'size' => array(
					'desktop' => '',
				),
				'lineHeight' => array(
					'desktop' => '',
				),
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '',
				'variant' => '',
			),
			'page_title_breadcrumb_font'   => array(
				'size' => array(
					'desktop' => '16',
				),
				'lineHeight' => array(
					'desktop' => '',
				),
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '400',
				'variant' => '400',
			),
			'page_title_elements'      => array( 'breadcrumb', 'title', 'meta' ),
			'page_title_element_breadcrumb' => array(
				'enabled' => true,
				'show_title' => true,
			),
			// Footer.
			'footer_items'       => array(
				'top' => array(
					'top_1' => array('footer-widget5'),
					'top_2' => array(''),
					'top_3' => array(),
					'top_4' => array(),
					'top_5' => array(),
				),
				'middle' => array(
					'middle_1' => array('footer-widget1','footer-social'),
					'middle_2' => array('footer-widget2'),
					'middle_3' => array('footer-widget3'),
					'middle_4' => array('footer-widget4'),
					'middle_5' => array(),
				),
				'bottom' => array(
					'bottom_1' => array( 'footer-html' ),
					'bottom_2' => array('footer-widget6'),
					'bottom_3' => array(),
					'bottom_4' => array(),
					'bottom_5' => array(),
				),
			),
			// Footer Top.
			'footer_top_columns' => '1',
			'footer_middle_columns' => '4',
			'footer_bottom_columns' => '2',
			'footer_wrap_background' => array(
				'desktop' => array(
					'type' => 'image',
					'image' => array(
						'url' => get_stylesheet_directory_uri() .'/assets/images/footer_bg.jpg',
						'repeat' => 'no-repeat',
						'size' => 'cover',
						'attachment' => 'scroll',
					),
				),
			),	
			'footer_top_contain'         => array(
					'mobile'  => '',
					'tablet'  => '',
					'desktop' => 'standard',
			),
			'footer_top_height' => array(
				'size' => array(
					'mobile'  => '',
					'tablet'  => '',
					'desktop' => '130',
				),
				'unit' => array(
					'mobile'  => 'px',
					'tablet'  => 'px',
					'desktop' => 'px',
				),
			),
			'footer_top_top_spacing' => array(
				'size' => array(
					'mobile'  => '',
					'tablet'  => '28',
					'desktop' => '28',
				),
				'unit' => array(
					'mobile'  => 'px',
					'tablet'  => 'px',
					'desktop' => 'px',
				),
			),
			'footer_top_bottom_spacing' => array(
				'size' => array(
					'mobile'  => '',
					'tablet'  => '28',
					'desktop' => '28',
				),
				'unit' => array(
					'mobile'  => 'px',
					'tablet'  => 'px',
					'desktop' => 'px',
				),
			),		
			'footer_top_widget_title'  => array(
				'size' => array(
					'mobile'  => '30',
					'tablet'  => '',
					'desktop' => '40',
				),
				'lineHeight' => array(
					'desktop' => '',
				),
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '700',
				'variant' => '700',
				'color'   => 'palette9',
				'transform' => 'capitalize',
			),
			'footer_top_background' => array(
				'desktop' => array(
					'color' => '',
				),
			),
			// Footer Middle.
			'footer_middle_height' => array(
				'size' => array(
					'mobile'  => '',
					'tablet'  => '',
					'desktop' => '390',
				),
				'unit' => array(
					'mobile'  => 'px',
					'tablet'  => 'px',
					'desktop' => 'px',
				),
			),
			'footer_middle_layout'  => array(
						'mobile'  => 'row',
						'tablet'  => '',
						'desktop' => 'left-forty',
					),	
				'footer_middle_direction'         => array(
					'mobile'  => '',
					'tablet'  => '',
					'desktop' => 'column',
				),
				'footer_middle_column_spacing' => array(
					'size' => array(
						'mobile'  => '',
						'tablet'  => '0',
						'desktop' => '113',
					),
					'unit' => array(
						'mobile'  => 'px',
						'tablet'  => 'px',
						'desktop' => 'px',
					),
				),
				'footer_middle_top_spacing' => array(
					'size' => array(
						'mobile'  => '40',
						'tablet'  => '',
						'desktop' => '75',
					),
					'unit' => array(
						'mobile'  => 'px',
						'tablet'  => 'px',
						'desktop' => 'px',
					),
				),
				'footer_middle_bottom_spacing' => array(
					'size' => array(
						'mobile'  => '40',
						'tablet'  => '',
						'desktop' => '75',
					),
					'unit' => array(
						'mobile'  => 'px',
						'tablet'  => 'px',
						'desktop' => 'px',
					),
				),
				'footer_middle_link_style' => 'noline',				
				'footer_middle_widget_title'  => array(
					'size' => array(
						'desktop' => '23',
					),
					'lineHeight' => array(
						'desktop' => '',
					),
					'family'  => 'inherit',
					'google'  => false,
					'transform' => 'capitalize',
					'weight'  => '700',
					'variant' => '700',
					'color'   => 'palette9',
				),
				'footer_middle_widget_content' => array(
					'size' => array(
						'desktop' => '',
					),
					'lineHeight' => array(
						'desktop' => '',
					),
					'family'  => 'inherit',
					'google'  => false,
					'weight'  => '',
					'variant' => '',
					'color'   => 'palette9',
				),
				'footer_middle_link_colors' => array(
					'color' => 'palette9',
					'hover' => 'palette5',
				),
				// Footer HTML.
				'footer_html_content'    => ' {copyright} {year} All Rights Reserved. Developed By CoderPlace',
				'footer_html_link_style'    => 'plain',
				'footer_html_margin' => array(
					'size'   => array( '8', '0', '8', '0' ),
					'unit'   => 'px',
					'locked' => false,
				),
				'footer_html_typography' => array(
					'size' => array(
						'desktop' => '',
					),
					'lineHeight' => array(
						'desktop' => '',
					),
					'family'  => 'inherit',
					'google'  => false,
					'weight'  => '',
					'variant' => '',
					'color'   => 'palette9',
				),
				'footer_html_link_color'  => array(
					'color' => 'palette9',
					'hover' => '',
				),
				'footer_html_align'  => array(
					'mobile'  => 'center',
					'tablet'  => 'center',
					'desktop' => 'left',
				),
				// Footer Bottom.	
				'footer_middle_top_border'    => array(
					'desktop' => array(
					'width' => 1,
					'unit'  => 'px',
					'style' => 'solid',
					'color' => 'rgba(49,66,139,1)',
					),
				),
				'footer_middle_bottom_border'    => array(
					'desktop' => array(
					'width' => 1,
					'unit'  => 'px',
					'style' => 'solid',
					'color' => 'rgba(49,66,139,1)',
					),
				),
				'footer_bottom_top_spacing' => array(
					'size' => array(
						'mobile'  => '',
						'tablet'  => '',
						'desktop' => '23',
					),
					'unit' => array(
						'mobile'  => 'px',
						'tablet'  => 'px',
						'desktop' => 'px',
					),
				),
				'footer_bottom_bottom_spacing' => array(
					'size' => array(
						'mobile'  => '',
						'tablet'  => '',
						'desktop' => '23',
					),
					'unit' => array(
						'mobile'  => 'px',
						'tablet'  => 'px',
						'desktop' => 'px',
					),
				),
				
				// Footer Widget 5.
				'footer_widget5_align'         => array(
					'mobile'  => 'center',
					'tablet'  => '',
					'desktop' => 'left',
				),
				'footer_widget5_vertical_align'         => array(
					'mobile'  => '',
					'tablet'  => '',
					'desktop' => 'middle',
				),
				// Footer Widget 6.
				'footer_widget6_align'         => array(
					'mobile'  => '',
					'tablet'  => '',
					'desktop' => 'right',
				),
				'footer_widget6_vertical_align'         => array(
					'mobile'  => '',
					'tablet'  => '',
					'desktop' => 'middle',
				),
					// Footer Social.
			'footer_social_items' => array(
				'items' => array(
					array(
						'id'      => 'facebook',
						'enabled' => true,
						'source'  => 'icon',
						'url'     => '',
						'imageid' => '',
						'width'   => 20,
						'icon'    => 'facebookAlt2',
						'label'   => 'Facebook',
					),
					array(
						'id'      => 'twitter',
						'enabled' => true,
						'source'  => 'icon',
						'url'     => '',
						'imageid' => '',
						'width'   => 20,
						'icon'    => 'twitter',
						'label'   => 'Twitter',
					),
					array(
						'id'      => 'instagram',
						'enabled' => true,
						'source'  => 'icon',
						'url'     => '',
						'imageid' => '',
						'width'   => 20,
						'icon'    => 'instagramAlt',
						'label'   => 'Instagram',
					),
					array(
						'id'      => 'google_reviews',
						'enabled' => true,
						'source'  => 'icon',
						'url'     => '',
						'imageid' => '',
						'width'   => 20,
						'icon'    => 'google_reviews',
						'label'   => 'google_reviews',
					),
				),
			),
					'footer_social_vertical_align'         => array(
						'mobile'  => 'middle',
						'tablet'  => 'middle',
						'desktop' => 'middle',
					),
					'footer_social_align'         => array(
						'mobile'  => '',
						'tablet'  => '',
						'desktop' => '',
					),
					'footer_social_margin' => array(
						'size'   => array( '0', '0', '30', '0' ),
						'unit'   => 'px',
						'locked' => false,
					),
					'footer_social_style'        => 'outline',
					'footer_social_color' => array(
						'color' => 'palette9',
						'hover' => 'palette5',
					),
					'footer_social_icon_size' => array(
						'size' => 1.15,
						'unit' => 'em',
					),
			// Scroll To Top.
			'scroll_up'               => true,
			'scroll_up_side'          => 'right',
			'scroll_up_icon'          => 'arrow-up',
			'scroll_up_icon_size'   => array(
				'size' => array(
					'mobile'  => '',
					'tablet'  => '',
					'desktop' => 1.2,
				),
				'unit' => array(
					'mobile'  => 'em',
					'tablet'  => 'em',
					'desktop' => 'em',
				),
			),
			'scroll_up_color' => array(
				'color'  => 'palette2',
				'hover'  => 'palette5',
			),
			// Search Results.
			'search_archive_title_background'   => array(
				'desktop' => array(
				'type' => 'image',
				'image' => array(
				'url' => get_stylesheet_directory_uri() .'/assets/images/breadcrumb.jpg',
				'repeat' => 'no-repeat',
				'size' => 'cover',
				'attachment' => 'scroll',
				),
				),
			),
			'search_archive_layout'  => 'left',
			'search_archive_title_layout' => 'above',
			'search_archive_columns'  => '2',
			'search_archive_element_meta' => array(
				'id'                     => 'meta',
				'enabled'                => true,
				'divider'                => 'customicon',
				'author'                 => false,
				'authorLink'             => true,
				'authorImage'            => false,
				'authorImageSize'        => 25,
				'authorEnableLabel'      => true,
				'authorLabel'            => '',
				'date'                   => true,
				'dateEnableLabel'        => false,
				'dateLabel'              => '',
				'dateUpdated'            => false,
				'dateUpdatedEnableLabel' => false,
				'dateUpdatedLabel'       => '',
				'categories'             => false,
				'categoriesEnableLabel'  => false,
				'categoriesLabel'        => '',
				'comments'               => false,
			),
			'search_archive_element_excerpt' => array(
				'enabled'     => true,
				'words'       => 21,
				'fullContent' => false,
			),
			'search_archive_element_readmore' => array(
				'enabled' => false,
				'label'   => '',
			),
			'search_archive_title_color' => array(
				'color' => 'palette9',
			),
			'search_archive_item_title_font'   => array(
				'size' => array(
					'desktop' => '23',
				),
				'lineHeight' => array(
					'mobile'  => '1.2',
					'tablet'  => '1.2',
					'desktop' => '1.2',
				),
				'lineType'=> 'em',
				'family'  => '',
				'google'  => false,
				'weight'  => '700',
				'variant' => '700',
			),
			'search_archive_item_meta_color' => array(
				'color' => 'palette1',
				'hover' => 'palette5',
			),
			'search_archive_item_meta_font'   => array(
				'size' => array(
					'desktop' => '16',
				),
				'lineHeight' => array(
					'desktop' => '0',
				),
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '400',
				'variant' => '400',
			),
			// Post Archive.
			'post_related_background' => array(
				'desktop' => array(
					'color' => 'palette9',
				),
			),
			'post_archive_layout'  => 'left',
			'post_archive_columns'  => '2',
			
			'post_archive_item_title_font'   => array(
				'size' => array(
					'desktop' => '23',
				),
				'lineHeight' => array(
					'desktop' => '',
				),
				'family'  => '',
				'google'  => false,
				'weight'  => '700',
				'variant' => '700',
			),
			'post_archive_item_meta_font'   => array(
				'size' => array(
					'desktop' => '16',
				),
				'lineHeight' => array(
					'desktop' => '0',
				),
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '400',
				'variant' => '400',
			),
			'post_archive_item_meta_color' => array(
				'color' => 'palette1',
				'hover' => 'palette5',
			),
			'post_archive_element_meta' => array(
				'id'                     => 'meta',
				'enabled'                => true,
				'divider'                => 'vline',
				'author'                 => false,
				'authorLink'             => false,
				'authorImage'            => false,
				'authorImageSize'        => 25,
				'authorEnableLabel'      => true,
				'authorLabel'            => '',
				'date'                   => true,
				'dateEnableLabel'        => false,
				'dateLabel'              => '',
				'dateUpdated'            => false,
				'dateUpdatedEnableLabel' => true,
				'dateUpdatedLabel'       => '',
				'categories'             => false,
				'categoriesEnableLabel'  => false,
				'categoriesLabel'        => '',
				'comments'               => false,
			),
			'post_archive_element_excerpt' => array(
				'enabled'     => true,
				'words'       => 21,
				'fullContent' => false,
			),
			'post_archive_element_readmore' => array(
				'enabled' => false,
				'label'   => '',
			),
			'post_archive_title_color' => array(
				'color' => 'palette9',
			),
			'post_archive_title_element_breadcrumb' => array(
				'enabled' => true,
				'show_title' => true,
			),
			'post_archive_title_breadcrumb_color' => array(
				'color' => 'palette9',
				'hover' => 'palette9',
			),	
			'post_archive_title_background'   => array(
				'desktop' => array(
				'type' => 'image',
				'image' => array(
				'url' => get_stylesheet_directory_uri() .'/assets/images/breadcrumb.jpg',
				'repeat' => 'no-repeat',
				'size' => 'cover',
				'attachment' => 'scroll',
				),
				),
			),		
			// Post Layout.
			'post_title_background'    => array(
				'desktop' => array(
				'type' => 'image',
				'image' => array(
				'url' => get_stylesheet_directory_uri() .'/assets/images/breadcrumb.jpg',
				'repeat' => 'no-repeat',
				'size' => 'cover',
				'attachment' => 'scroll',
				),
				),
			),
			'post_layout'             => 'normal',
			'post_content_style'      => 'boxed',
			'post_vertical_padding'   => 'bottom',
			'post_feature_position'   => 'behind',
			'post_feature_width'      => 'full',
			'post_tags'               => true,
			'post_author_box'         => false,
			'post_author_box_style'   => 'normal',
			'post_title'              => true,
			'post_title_layout'       => 'normal',
			'post_title_align'         => array(
				'mobile'  => 'left',
				'tablet'  => 'left',
				'desktop' => 'left',
			),
			'post_title_height'       => array(
				'size' => array(
					'mobile'  => '120',
					'tablet'  => '150',
					'desktop' => '200',
				),
				'unit' => array(
					'mobile'  => 'px',
					'tablet'  => 'px',
					'desktop' => 'px',
				),
			),
			'post_title_element_meta' => array(
				'id'                     => 'meta',
				'enabled'                => true,
				'divider'                => 'vline',
				'author'                 => true,
				'authorLink'             => true,
				'authorImage'            => true,
				'authorImageSize'        => 25,
				'authorEnableLabel'      => true,
				'authorLabel'            => '',
				'date'                   => true,
				'dateEnableLabel'        => false,
				'dateLabel'              => '',
				'dateUpdated'            => false,
				'dateUpdatedEnableLabel' => false,
				'dateUpdatedLabel'       => '',
				'categories'             => true,
				'categoriesEnableLabel'  => false,
				'categoriesLabel'        => '',
				'comments'               => true,
			),
			'post_title_category_font'   => array(
				'size' => array(
					'desktop' => '16',
				),
				'lineHeight' => array(
					'desktop' => '',
				),
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '400',
				'variant' => '400',
			),
			'post_title_category_color' => array(
				'color' => 'palette2',
				'hover' => '',
			),
			'post_title_meta_font'   => array(
				'size' => array(
					'desktop' => '16',
				),
				'lineHeight' => array(
					'desktop' => '',
				),
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '400',
				'variant' => '400',
			),
			// Sidebar.
			'sidebar_width'   => array(
				'size' => '22',
				'unit' => '%',
			),
			'sidebar_widget_spacing'   => array(
				'size' => array(
					'mobile'  => '',
					'tablet'  => 1.5,
					'desktop' => 1.875,
				),
				'unit' => array(
					'mobile'  => 'em',
					'tablet'  => 'em',
					'desktop' => 'em',
				),
			),
			'sidebar_widget_title' => array(
				'size' => array(
					'desktop' => 23,
				),
				'lineHeight' => array(
					'desktop' => 1.5,
				),
				'family'  => 'Rajdhani',
				'transform' => 'capitalize',
				'google'  => false,
				'weight'  => '700',
				'variant' => '700',
				'color'   => 'palette1',
			),
			'sidebar_widget_content'            => array(
				'size' => array(
					'desktop' => '16',
				),
				'lineType'=> 'em',
				'lineHeight' => array(
					'desktop' => '1.5',
				),
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '400',
				'variant' => '400',
				'color'   => 'palette1',
			),
			'sidebar_link_style' => 'plain',
			'sidebar_link_colors' => array(
				'color' => 'palette1',
				'hover' => 'palette2',
			),
			// Product Archive Controls.
			'product_archive_title_elements'      => array( 'breadcrumb', 'title', 'description' ),
			'product_archive_title_element_breadcrumb' => array(
				'enabled' => true,
				'show_title' => true,
			),
			'product_archive_title_background'  => array(
				'desktop' => array(
				'type' => 'image',
				'image' => array(
				'url' => get_stylesheet_directory_uri() .'/assets/images/breadcrumb.jpg',
				'repeat' => 'no-repeat',
				'size' => 'cover',
				'attachment' => 'scroll',
				),
				),
			),
			'product_archive_layout'  => 'left',
			'product_archive_content_style'      => 'unboxed',
			'product_archive_sidebar_id'  => 'sidebar-secondary',
			'product_archive_title_font'   => array(
				'size' => array(
					'desktop' => '16',
				),
				'lineHeight' => array(
					'desktop' => '1.5',
				),
				'lineType' =>  'em',
				'letterSpacing' => array(
					'mobile' => '',
					'tablet' => '',
					'desktop' => '0.3',
				),
				'spacingType'=> 'px',
				'transform' => 'inherit',
				'family'  => 'inherit' ,
				'google'  => false,
				'weight'  => '400',
				'variant' => '400',
				'color'   => 'palette3',
			),
			'product_archive_price_font'   => array(
				'size' => array(
					'desktop' => '16',
				),
				'lineHeight' => array(
					'desktop' => '24',
				),
				'lineType' =>  'px',
				'letterSpacing' => array(
					'mobile' => '',
					'tablet' => '',
					'desktop' => '0.3',
				),
				'spacingType'=> 'px',
				'transform' => 'inherit',
				'family'  => 'inherit',
				'google'  => true,
				'weight'  => '400',
				'variant' => '400',
				'color'   => 'palette1',
			),
			'product_archive_title_color' => array(
				'color' => 'palette9',
			),
			'product_archive_title_breadcrumb_color' => array(
				'color' => 'palette9',
				'hover' => 'palette9',
			),
			// Product Controls.
			'product_title_background' => array(
				'desktop' => array(
				'type' => 'image',
				'image' => array(
				'url' => get_stylesheet_directory_uri() .'/assets/images/breadcrumb.jpg',
				'repeat' => 'no-repeat',
				'size' => 'cover',
				'attachment' => 'scroll',
				),
				),
			),
			'product_above_layout'  => 'title',
			'custom_quantity'  => true,
			'product_tab_title'   => false,
			'product_title_breadcrumb_color' => array(
				'color' => 'palette9',
				'hover' => 'palette2',
			),
			'product_title_element_category' => array(
				'enabled' => false,
			),
			'product_title_element_above_title' => array(
				'enabled' => true,
			),
			'product_title_element_breadcrumb' => array(
				'enabled' => true,
				'show_title' => true,
			),
			'product_content_element_category' => array(
				'enabled' => true,
			),
			'product_content_element_title' => array(
				'enabled' => false,
			),
			'product_above_title_font'   => array(
				'size' => array(
					'desktop' => '',
				),
				'lineHeight' => array(
					'desktop' => '',
				),
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '',
				'variant' => '',
				'color'   => 'palette9',
			),
			'product_content_element_rating' => array(
				'enabled' => true,
			),
			'product_content_element_price' => array(
				'enabled' => true,
				'show_shipping' => true,
				'shipping_statement' => __( '& Free Shipping', 'basetheme' ),
			),
			'product_content_element_excerpt' => array(
				'enabled' => true,
			),
			'product_content_element_add_to_cart' => array(
				'enabled'     => true,
				'button_size' => '',
			),
			'product_content_element_extras' => array(
				'enabled'   => true,
				'title'     => __( 'Free shipping on orders over $50!', 'basetheme' ),
				'feature_1' => __( 'Satisfaction Guaranteed', 'basetheme' ),
				'feature_2' => __( 'No Hassle Refunds', 'basetheme' ),
				'feature_3' => __( 'Secure Payments', 'basetheme' ),
				'feature_4' => '',
				'feature_5' => '',
				'feature_1_icon' => 'shield_check',
				'feature_2_icon' => 'shield_check',
				'feature_3_icon' => 'shield_check',
				'feature_4_icon' => 'shield_check',
				'feature_5_icon' => 'shield_check',
			),
			'product_title_font'   => array(
				'size' => array(
					'mobile'  => '24',
					'tablet'  => '30',
					'desktop' => '50',
				),
				'lineHeight' => array(
					'mobile'  => '',
					'tablet'  => '',
					'desktop' => '1',
				),
				'lineType' =>  '',
				'letterSpacing' => array(
					'mobile'  => '0',
					'tablet'  => '0',
					'desktop' => '0',
				),
				'spacingType'=> 'px',
				'transform' => '',
				'family'  => 'inherit',
				'google'  => true,
				'weight'  => '',
				'variant' => '',
				'color'   => '',
			),
		);
		
		$defaults = array_merge(
			$defaults,
			$update_options
		);
		return $defaults;
	}

	public function add_addons_option_defaults( $defaults ) {
		$addons_update_options = array(
			'header_html2_typography' => array(
			'size' => array(
			'desktop' => '30',
				),			
			),			
			// Header Divider.
			'header_divider_height'    => array(
				'size' => 19,
				'unit' => 'px',
			),
			'header_divider_border'  => array(
				'width' => '1',
				'unit'  => 'px',
				'style' => 'solid',
				'color'  => '#4f5e9c',
			),
			'header_divider_margin' => array(
				'size'   => array( '0', '10', '0', '10' ),
				'unit'   => 'px',
				'locked' => false,
				),	
			// Header Contact.
			'header_contact_items' => array(
				'items' => array(				
					array(
						'id'      => 'hours',
						'enabled' => true,
						'source'  => 'icon',
						'url'     => '',
						'imageid' => '',
						'width'   => 24,
						'link'     => '',
						'icon'    => 'hours',
						'label'   => 'Mon - Fri: 08.00 AM - 10.00 PM',
					),				
				),
			),
		'header_contact_item_spacing'=> array(
			'size' => 1.2,
			'unit' => 'em',
		),
		'header_contact_icon_size' => array(
			'size' => 1,
			'unit' => 'em',
		),
		'header_contact_color' => array(
			'color'  => 'palette9',
		),
		'header_contact_icon_color' => array(
			'color'  => 'palette2',
			'hover' => 'palette2',
		),
		'header_contact_typography'    => array(
				'size' => array(
					'desktop' => '',
				),
				'lineHeight' => array(
					'desktop' => '',
				),
				'lineType' =>  'px',
				'letterSpacing' => array(
					'desktop' => '',
				),
				'spacingType'=> 'px',
				'transform' => 'capitalize',
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '',
				'variant' => '',
			),
		// Mobile Header Contact.
		'header_mobile_contact_items' => array(
			'items' => array(				
				array(
					'id'      => 'hours',
					'enabled' => true,
					'source'  => 'icon',
					'url'     => '',
					'imageid' => '',
					'width'   => 24,
					'link'     => '',
					'icon'    => 'hours',
					'label'   => 'Mon - Fri: 08.00am - 10.00 pm',
				),				
			),
		),
			'header_account_label'  => __( 'Login / Register', 'basetheme' ),
			'header_account_link' => 'https://demo.coderplace.com/wp/WP02/WP02029/my-account/',
			'header_account_style' => 'label',
			'header_account_color' => array(
				'color' => 'palette9',
				'hover' => 'palette9',
			),
			'header_account_typography' => array(
				'size' => array(
					'desktop' => '16',
				),
				'lineHeight' => array(
					'desktop' => '18',
				),
				'lineType' =>  'px',
				'letterSpacing' => array(
					'desktop' => '0',
				),
				'spacingType'=> 'px',
				'transform' => 'capitalize',
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '400',
				'variant' => '400',
			),
			'header_account_in_typography' => array(
				'size' => array(
					'desktop' => '16',
				),
				'lineHeight' => array(
					'desktop' => '18',
				),
				'lineType' =>  'px',
				'letterSpacing' => array(
					'desktop' => '0',
				),
				'spacingType'=> 'px',
				'transform' => 'capitalize',
				'family'  => 'inherit',
				'google'  => false,
				'weight'  => '400',
				'variant' => '400',
			),
			'header_account_in_style'                   => 'label',
			'header_account_in_label'                   => __( 'My Account', 'basetheme' ),
			'header_account_in_color' => array(
				'color' => 'palette9',
				'hover' => 'palette9',
			),
			'header_account_in_link' => '192.168.0.101/user24/Wordpress/clenox/my-account/',	
			// Header HTML.
			'header_html_content'    => __( '<div class="contact-contain"><span class="title">Call : (+1)258 998 336</span>
			</div>', 'coderplace' ),
			'header_html_typography' => array(
				'size' => array(
					'desktop' => '16',
				),
				'lineHeight' => array(
					'desktop' => '',
				),
				'family'  => '',
				'google'  => false,
				'weight'  => '400',
				'variant' => '400',
				'color'   => 'palette9',
			),						
		);
		$defaults = array_merge(
		$defaults,
		$addons_update_options
		);
		return $defaults;
		}

}

Custom_Theme::get_instance();
